// @bun
// ../../../protocol/src/constants.ts
import { homedir, platform } from "os";
import { join } from "path";
var isWin = platform() === "win32";
var isMac = platform() === "darwin";
function getDataDir() {
  if (isWin) {
    return join(process.env.APPDATA ?? join(homedir(), "AppData", "Roaming"), "mini");
  }
  if (isMac) {
    return join(homedir(), ".local", "share", "mini");
  }
  return join(process.env.XDG_DATA_HOME ?? join(homedir(), ".local", "share"), "mini");
}
var DEFAULT_DATA_DIR = getDataDir();
var DEFAULT_SOCK = isWin ? "\\\\.\\pipe\\mini" : join(DEFAULT_DATA_DIR, "bridge.sock");
// src/mode.ts
function detectMode() {
  return process.argv.includes("serve") ? "attach" : "standalone";
}
function detectRunMode() {
  if (process.argv.includes("serve"))
    return "serve";
  if (process.argv.includes("attach"))
    return "attach";
  return "tui";
}
function getServePort() {
  if (!process.argv.includes("serve"))
    return;
  const idx = process.argv.indexOf("--port");
  return idx >= 0 && idx + 1 < process.argv.length ? process.argv[idx + 1] : undefined;
}

// src/connection.ts
var FATAL_ACK_CODES = new Set(["PROTOCOL_MISMATCH", "UNKNOWN_AGENT", "AGENT_DISABLED"]);
var RECONNECT_MS = 2000;
function createConnection(opts) {
  let sock = null;
  let buffer = "";
  let stopped = false;
  let stopReason;
  let reconnectScheduled = false;
  const scheduleReconnect = () => {
    if (stopped || reconnectScheduled)
      return;
    reconnectScheduled = true;
    setTimeout(() => {
      reconnectScheduled = false;
      connect();
    }, RECONNECT_MS);
  };
  const sendFrame = (frame) => {
    if (!sock)
      return false;
    try {
      sock.write(JSON.stringify(frame) + `
`);
      return true;
    } catch {
      return false;
    }
  };
  const sendEvent = (normalized) => sendFrame({
    type: "event",
    v: 1,
    directory: opts.register.directory,
    pid: opts.register.pid,
    normalized
  });
  const sendCommandResult = (result) => sendFrame(result);
  const handleAck = (ack) => {
    if (ack.ok !== false) {
      try {
        opts.onReestablished?.();
      } catch {}
      return;
    }
    console.error(`[mini-bridge] register rejected: ${ack.error ?? "unknown"}`);
    if (ack.error && FATAL_ACK_CODES.has(ack.error)) {
      stopped = true;
      stopReason = `register-ack rejected (${ack.error})`;
      console.error(`[mini-bridge] ${stopReason} \u2014 stop reconnecting`);
      try {
        sock?.end();
      } catch {}
    }
  };
  const connect = async () => {
    if (stopped)
      return;
    try {
      sock = await Bun.connect({
        unix: opts.sockPath,
        socket: {
          data(_socket, data) {
            buffer += data.toString();
            const lines = buffer.split(`
`);
            buffer = lines.pop() ?? "";
            for (const line of lines) {
              const trimmed = line.trim();
              if (!trimmed)
                continue;
              let msg;
              try {
                msg = JSON.parse(trimmed);
              } catch {
                continue;
              }
              const type = msg.type;
              if (type === "register-ack") {
                handleAck(msg);
              } else if (type === "command") {
                const cmd = msg;
                opts.onCommand(cmd).catch((e) => ({ ok: false, error: String(e?.message ?? e) })).then((res) => {
                  sendCommandResult({
                    type: "command-result",
                    v: 1,
                    id: cmd.id ?? "",
                    ok: res.ok,
                    ...res.error !== undefined ? { error: res.error } : {},
                    ...res.data !== undefined ? { data: res.data } : {}
                  });
                });
              }
            }
          },
          open(socket) {
            sock = socket;
            buffer = "";
            socket.write(JSON.stringify(opts.register) + `
`);
          },
          close() {
            sock = null;
            buffer = "";
            scheduleReconnect();
          },
          error() {
            sock = null;
            buffer = "";
            scheduleReconnect();
          }
        }
      });
    } catch {
      scheduleReconnect();
    }
  };
  return { connect, sendFrame, sendEvent, sendCommandResult };
}

// src/commands.ts
var rawPost = (client, url, path, body) => {
  const c = client._client;
  if (!c)
    throw new Error("raw client unavailable");
  return c.post({ url, path, body });
};
var unwrap = (r) => r?.data ?? r;
var arrOf = (list) => Array.isArray(list) ? list : list?.data || [];
var payloadOf = (cmd) => cmd.payload && typeof cmd.payload === "object" ? cmd.payload : {};
var serveSessionIDPath = (id) => ({ id });
function createCommandHandler(client, directory, emitEvent, opts) {
  const getSessionID = opts?.getSessionID;
  const isServe = opts?.runMode === "serve";
  const note = (m) => console.warn(`[mini-bridge][serve] ${m}`);
  const resolveServeSessionID = async () => {
    const sid = getSessionID?.();
    if (sid)
      return sid;
    const created = await rawPost(client, "/session?directory=" + encodeURIComponent(directory), {}, undefined);
    const w = unwrap(created);
    const id = w && typeof w === "object" ? w.id : undefined;
    if (typeof id !== "string" || id === "") {
      throw new Error("serve: POST /session?directory= ... no session id in response");
    }
    return id;
  };
  const resolveShareSessionID = async (cmdSessionID) => {
    let sessionID = cmdSessionID ?? getSessionID?.();
    if (!sessionID) {
      const arr = arrOf(await client.session.list());
      sessionID = arr.find((s) => s.directory === directory)?.id;
    }
    return sessionID;
  };
  const handle = async (cmd) => {
    const p = payloadOf(cmd);
    try {
      switch (cmd.action) {
        case "send": {
          const msg = p.text ?? p.message;
          if (!msg)
            return { ok: true, data: { skipped: "no text" } };
          if (isServe) {
            const sessionID = await resolveServeSessionID();
            await rawPost(client, "/session/{id}/message", serveSessionIDPath(sessionID), {
              parts: [{ type: "text", text: msg }],
              noReply: false
            });
            return { ok: true, data: { sessionID } };
          }
          await client.tui.appendPrompt({ query: { directory }, body: { text: msg } });
          await new Promise((r) => setTimeout(r, 300));
          await client.tui.submitPrompt({ query: { directory } });
          return { ok: true };
        }
        case "append": {
          const msg = p.text ?? p.message;
          if (!msg)
            return { ok: true, data: { skipped: "no text" } };
          if (isServe) {
            note("append \u964D\u7EA7\uFF1Aserve \u65E0\u8349\u7A3F\u7BB1\uFF0C\u5DF2\u8BB0\u5F55\uFF08\u672A\u53D1\u9001\uFF09");
            return { ok: true, data: { degraded: "append has no draft box in serve mode; recorded only" } };
          }
          await client.tui.appendPrompt({ query: { directory }, body: { text: msg } });
          return { ok: true };
        }
        case "submit": {
          if (isServe) {
            note("submit \u964D\u7EA7\uFF1Aserve \u65E0\u53EF\u63D0\u4EA4\u8349\u7A3F\uFF0Cno-op");
            return { ok: true, data: { degraded: "submit is a no-op in serve mode (no draft to submit)" } };
          }
          await client.tui.submitPrompt({ query: { directory } });
          return { ok: true };
        }
        case "command": {
          const slash = p.command ?? p.text;
          if (!slash)
            return { ok: true, data: { skipped: "no command" } };
          if (isServe) {
            const sessionID = await resolveServeSessionID();
            await rawPost(client, "/session/{id}/command", serveSessionIDPath(sessionID), { command: slash });
            return { ok: true, data: { sessionID } };
          }
          await client.tui.executeCommand({ query: { directory }, body: { command: slash } });
          return { ok: true };
        }
        case "abort": {
          const arr = arrOf(await client.session.list());
          const target = p.sessionID ?? getSessionID?.() ?? arr.find((s) => s.directory === directory)?.id ?? arr[0]?.id;
          if (!target)
            return { ok: true, data: { skipped: "no session to abort" } };
          await client.session.abort({ path: { id: target } });
          return { ok: true, data: { sessionID: target } };
        }
        case "permission-reply": {
          const permissionId = p.permissionId;
          const response = p.reply ?? p.permissionResponse;
          if (!permissionId || !response) {
            return { ok: true, data: { skipped: "missing permissionId or reply" } };
          }
          await rawPost(client, "/permission/{requestID}/reply", { requestID: permissionId }, { reply: response });
          return { ok: true };
        }
        case "close": {
          if (isServe) {
            note("close \u5DF2\u62E6\u622A\uFF1Aserve \u540C\u8FDB\u7A0B\u4F1A\u6740\u5BBF\u4E3B\uFF0C\u53EA\u505A\u4EFB\u52A1\u7EA7\u6E05\u7406");
            return { ok: true, data: { intercepted: "close intercepted in serve mode; task-level cleanup only" } };
          }
          try {
            if (client.instance)
              await client.instance.dispose();
          } catch {}
          setTimeout(() => process.exit(0), 300);
          return { ok: true };
        }
        case "question-reply": {
          if (!p.questionId)
            return { ok: true, data: { skipped: "missing questionId" } };
          await rawPost(client, "/question/{requestID}/reply", { requestID: p.questionId }, { answers: p.answers ?? [[]] });
          return { ok: true };
        }
        case "question-reject": {
          if (!p.questionId)
            return { ok: true, data: { skipped: "missing questionId" } };
          await rawPost(client, "/question/{requestID}/reject", { requestID: p.questionId });
          return { ok: true };
        }
        case "share": {
          const sessionID = await resolveShareSessionID(p.sessionID);
          if (!sessionID)
            return { ok: true, data: { skipped: "no session to share" } };
          if (typeof client.session.share !== "function") {
            const error2 = "share failed: client.session.share is not a function";
            emitEvent?.({ share: { error: error2 }, lastEvent: "share" });
            return { ok: false, error: error2 };
          }
          const res = await client.session.share({ path: { id: sessionID } });
          const unwrapped = unwrap(res);
          if (unwrapped?.share?.url) {
            emitEvent?.({ share: { url: unwrapped.share.url }, lastEvent: "share" });
            return { ok: true, data: { url: unwrapped.share.url } };
          }
          let existing;
          try {
            const g = await client.session.get?.({ path: { id: sessionID } });
            existing = unwrap(g)?.share?.url;
          } catch {
            existing = undefined;
          }
          if (existing) {
            emitEvent?.({ share: { url: existing }, lastEvent: "share" });
            return { ok: true, data: { url: existing } };
          }
          const error = `share failed: no url in result: ${JSON.stringify(unwrapped).slice(0, 200)}`;
          emitEvent?.({ share: { error }, lastEvent: "share" });
          return { ok: false, error };
        }
        case "unshare": {
          const sessionID = await resolveShareSessionID(p.sessionID);
          if (!sessionID)
            return { ok: true, data: { skipped: "no session to unshare" } };
          if (typeof client.session.unshare !== "function") {
            const error = "unshare failed: client.session.unshare is not a function";
            emitEvent?.({ share: { error }, lastEvent: "unshare" });
            return { ok: false, error };
          }
          await client.session.unshare({ path: { id: sessionID } });
          emitEvent?.({ share: {}, lastEvent: "unshare" });
          return { ok: true };
        }
        default:
          return { ok: true, data: { skipped: `unhandled action ${cmd.action}` } };
      }
    } catch (e) {
      return { ok: false, error: String(e?.message ?? e) };
    }
  };
  return { handle };
}

// src/normalize.ts
var asObject = (v) => v && typeof v === "object" ? v : undefined;
var eventData = (e) => e.data ?? e.properties;
function mapEventToStatus(type, data) {
  switch (type) {
    case "session.status": {
      const s = asObject(asObject(data)?.status)?.type;
      switch (typeof s === "string" ? s : undefined) {
        case "idle":
        case "lazy":
          return "idle";
        case "retry":
          return "retry";
        case "permission":
          return "permission";
        case "question":
          return "question";
        default:
          return "busy";
      }
    }
    case "session.idle":
      return "idle";
    case "permission.asked":
    case "permission.updated":
      return "permission";
    case "permission.replied":
    case "permission.rejected":
      return "busy";
    case "question.asked":
      return "question";
    case "question.replied":
    case "question.rejected":
      return "busy";
    case "session.error":
      return "error";
    case "session.retry":
      return "retry";
    default:
      return;
  }
}
function extractPermission(data) {
  const d = asObject(data);
  if (!d)
    return;
  const id = typeof d.id === "string" ? d.id : undefined;
  if (!id || id === "")
    return;
  const patterns = Array.isArray(d.patterns) ? d.patterns.filter((x) => typeof x === "string") : [];
  return {
    id,
    sessionID: typeof d.sessionID === "string" ? d.sessionID : "",
    permission: typeof d.permission === "string" ? d.permission : "",
    patterns,
    agent: "opencode",
    tool: null,
    action: null
  };
}
function extractQuestion(data) {
  const d = asObject(data);
  if (!d)
    return;
  const id = typeof d.id === "string" ? d.id : undefined;
  if (!id || id === "")
    return;
  const sessionID = typeof d.sessionID === "string" ? d.sessionID : "";
  const questions = [];
  if (Array.isArray(d.questions)) {
    for (const qi of d.questions) {
      const q = asObject(qi);
      if (!q)
        continue;
      const rawOptions = Array.isArray(q.options) ? q.options : [];
      const options = [];
      for (const oi of rawOptions) {
        const o = asObject(oi);
        if (!o)
          continue;
        options.push({
          label: typeof o.label === "string" ? o.label : "",
          description: typeof o.description === "string" ? o.description : ""
        });
      }
      questions.push({
        question: typeof q.question === "string" ? q.question : "",
        header: typeof q.header === "string" ? q.header : "",
        options,
        multiple: typeof q.multiple === "boolean" ? q.multiple : false,
        custom: typeof q.custom === "boolean" ? q.custom : true
      });
    }
  }
  return { id, sessionID, questions };
}
function normalizeEvent(event) {
  const type = event.type;
  const data = eventData(event);
  const status = mapEventToStatus(type, data);
  const out = {
    ...status !== undefined ? { status } : {},
    lastEvent: type
  };
  if (type === "session.updated") {
    const info = asObject(asObject(data)?.info);
    const title = typeof info?.title === "string" ? info.title : "";
    if (title !== "")
      out.title = { title };
  }
  const perm = extractPermission(data);
  if (type === "permission.asked" || type === "permission.updated") {
    if (perm)
      out.permission = { op: "set", value: perm };
  } else if (type === "permission.replied" || type === "permission.rejected" || type === "session.error") {
    out.permission = { op: "clear" };
  }
  const question = extractQuestion(data);
  if (type === "question.asked") {
    if (question)
      out.question = { op: "set", value: question };
  } else if (type === "question.replied" || type === "question.rejected" || type === "session.error") {
    out.question = { op: "clear" };
  }
  return out;
}

// src/events.ts
var isUrgent = (n) => n.status !== undefined || n.permission !== undefined || n.question !== undefined || n.title !== undefined || n.share !== undefined;
function createEventForwarder(sendEvent, opts) {
  const coalesceMs = opts?.coalesceMs ?? 120;
  const schedule = opts?.schedule ?? ((fn, ms) => setTimeout(fn, ms));
  let pending = [];
  let timer;
  let lastUrgentSnapshot;
  const flush = () => {
    timer = undefined;
    if (pending.length === 0)
      return;
    const out = [];
    for (const ev of pending) {
      const last = out[out.length - 1];
      if (last && last.lastEvent === ev.lastEvent)
        continue;
      out.push(ev);
    }
    pending = [];
    for (const ev of out)
      sendEvent(ev);
  };
  const forward = (event) => {
    try {
      const n = normalizeEvent(event);
      if (isUrgent(n)) {
        flush();
        if (n.status !== undefined || n.permission !== undefined || n.question !== undefined) {
          lastUrgentSnapshot = n;
        }
        sendEvent(n);
        return;
      }
      pending.push(n);
      if (timer === undefined)
        timer = schedule(flush, coalesceMs);
    } catch {}
  };
  return { forward, flush, lastUrgent: () => lastUrgentSnapshot };
}

// src/session.ts
import { readFileSync } from "fs";
var extractSessionIDFromCommandLine = (cmd) => {
  if (!cmd)
    return;
  const tokens = cmd.split(/\s+/);
  for (let i = 0;i < tokens.length; i++) {
    const t = tokens[i];
    if (t === "-s" || t === "--session") {
      const v = tokens[i + 1];
      if (v?.startsWith("ses_"))
        return v;
    } else if (t.startsWith("--session=")) {
      const v = t.slice("--session=".length);
      if (v.startsWith("ses_"))
        return v;
    } else if (t.startsWith("-s=")) {
      const v = t.slice("-s=".length);
      if (v.startsWith("ses_"))
        return v;
    }
  }
  return tokens.find((t) => t.startsWith("ses_"));
};
var readOwnCommandLine = (pid) => {
  try {
    try {
      const text = readFileSync(`/proc/${pid}/cmdline`, "utf8");
      if (text)
        return text.replace(/\0/g, " ");
    } catch {}
    const out = Bun.spawnSync(["ps", "-o", "command=", "-p", String(pid)]);
    if (out.exitCode !== 0)
      return;
    return (out.stdout?.toString() ?? "").trim();
  } catch {
    return;
  }
};

// src/index.ts
var MiniBridgePlugin = async (ctx) => {
  const { client, directory } = ctx;
  const mode = detectMode();
  const runMode = detectRunMode();
  const servePort = getServePort();
  const sockPath = process.env.MINI_SOCK || DEFAULT_SOCK;
  const version = process.env.OPENCODE_VERSION ?? "";
  const argvSessionID = extractSessionIDFromCommandLine(readOwnCommandLine(process.pid));
  const register = {
    type: "register",
    v: 1,
    protocol: "abp/1",
    agentId: "opencode",
    role: "task",
    directory,
    pid: process.pid,
    ...argvSessionID ? { sessionID: argvSessionID } : {},
    meta: {
      mode,
      runMode,
      ...servePort ? { servePort } : {},
      ...version ? { version } : {}
    },
    capabilities: { permission: "reply", question: true, abort: true, sessions: false }
  };
  let mySessionID;
  let lastActivityAt = Date.now();
  const IDLE_SKIP_MS = 1e4;
  const resolveMySession = async () => {
    const fromArgv = extractSessionIDFromCommandLine(readOwnCommandLine(process.pid));
    if (fromArgv)
      return fromArgv;
    try {
      const list = await Promise.race([
        client.session.list(),
        new Promise((resolve) => setTimeout(() => resolve(undefined), 5000))
      ]);
      if (!list)
        return;
      const sessions = Array.isArray(list) ? list : list?.data || [];
      const dirSessions = sessions.filter((s) => s.directory === directory);
      return dirSessions.sort((a, b) => (b.time?.updated ?? 0) - (a.time?.updated ?? 0))[0]?.id;
    } catch {
      return;
    }
  };
  const connection = createConnection({
    sockPath,
    register,
    onCommand: (cmd) => commands.handle(cmd),
    onReestablished: () => {
      const snap = events.lastUrgent();
      if (snap)
        connection.sendEvent(snap);
    }
  });
  const events = createEventForwarder(connection.sendEvent);
  const commands = createCommandHandler(client, directory, connection.sendEvent, { runMode, getSessionID: () => mySessionID });
  await connection.connect();
  let lastKey = "";
  let ctxCounter = 0;
  let lastContextTokens;
  const reportTitle = async () => {
    try {
      if (lastKey && Date.now() - lastActivityAt > IDLE_SKIP_MS)
        return;
      if (!mySessionID) {
        try {
          mySessionID = await resolveMySession();
        } catch {}
      }
      let best;
      if (mySessionID) {
        try {
          const g = await client.session.get?.({
            path: { id: mySessionID }
          });
          const gw = g?.data ?? g;
          if (gw && typeof gw === "object") {
            best = { ...gw, id: mySessionID };
          }
        } catch {
          best = undefined;
        }
      }
      if (!best) {
        const list = await client.session.list();
        const sessions = Array.isArray(list) ? list : list?.data || [];
        best = mySessionID ? sessions.find((s) => s.directory === directory && s.id === mySessionID) : undefined;
        if (!best && !mySessionID) {
          for (const s of sessions) {
            if (s.directory === directory) {
              if (!best || (s.time?.updated ?? 0) > (best.time?.updated ?? 0)) {
                best = s;
              }
            }
          }
        }
      }
      if (best) {
        const tokens = best.tokens ? {
          input: best.tokens.input ?? 0,
          output: best.tokens.output ?? 0,
          reasoning: best.tokens.reasoning ?? 0,
          cache_read: best.tokens.cache?.read ?? 0,
          cache_write: best.tokens.cache?.write ?? 0
        } : undefined;
        if (best.id && ++ctxCounter % 6 === 0) {
          try {
            if (client.session.context) {
              const ctx2 = await client.session.context({ sessionID: best.id });
              const msgs = Array.isArray(ctx2) ? ctx2 : ctx2?.data || [];
              lastContextTokens = msgs.find((m) => (m.tokens?.input ?? 0) > 0)?.tokens?.input;
            } else if (client.session.messages) {
              const ms = await client.session.messages({ path: { id: best.id }, query: { limit: 200 } });
              const arr = Array.isArray(ms) ? ms : ms?.data || [];
              let fallback;
              let latest;
              for (const m of arr) {
                const input = m.info?.tokens?.input;
                if (input === undefined || input === 0)
                  continue;
                if (fallback === undefined)
                  fallback = input;
                const created = m.info?.time?.created;
                if (created !== undefined) {
                  if (!latest || created > latest.created)
                    latest = { input, created };
                }
              }
              lastContextTokens = latest ? latest.input : fallback;
            } else {
              lastContextTokens = undefined;
            }
          } catch {}
        }
        const key = `${best.title ?? ""}:${best.cost ?? ""}:${JSON.stringify(tokens)}:${lastContextTokens ?? ""}`;
        if (key !== lastKey) {
          lastKey = key;
          connection.sendEvent({
            title: {
              title: best.title ?? "",
              sessionID: best.id,
              ...best.cost !== undefined ? { cost: best.cost } : {},
              ...tokens ? { tokens } : {},
              ...lastContextTokens !== undefined ? { contextTokens: lastContextTokens } : {}
            }
          });
        }
      }
    } catch {}
  };
  const titleTimer = setInterval(reportTitle, 2000);
  reportTitle();
  resolveMySession().then((id) => {
    mySessionID = id;
  }).catch(() => {});
  return {
    event: async ({ event }) => {
      lastActivityAt = Date.now();
      const ed = event.data ?? event.properties;
      if (event.type === "session.updated") {
        const info = ed?.info;
        if (info?.id)
          mySessionID = info.id;
      }
      if (event.type === "tui.session.select") {
        const sid = ed?.sessionID;
        if (sid)
          mySessionID = sid;
      }
      events.forward(event);
    },
    dispose: () => {
      clearInterval(titleTimer);
      events.flush();
    }
  };
};
export {
  MiniBridgePlugin
};

# template-bun —— ABP 全能力适配器模板（bun/node，零依赖）

对照本文件把 echo 参考实现改造成你的真实 agent。协议细节以 `Docs/specs/agent-bridge-protocol-v1.md` 为准。

## 形态总览

| 文件 | 职责 |
|------|------|
| `agent.json` | 清单：声明 `transport=bridge` + `launch`（任务模式拉起）+ `dataDaemon`（数据层常驻）+ `capabilities` |
| `adapter.mjs` | 同文件双模式：默认 `task`（任务进程，终态即退出）/ `--daemon`（数据层常驻，`role:"daemon"`） |

## 启动方式

由 hub 按清单自动拉起（两种模式），`cwd:"manifest-dir"` 使 `args:["adapter.mjs"]` 解析到清单所在目录：

- **任务模式**：`launch` = `bun adapter.mjs`。hub spawn 后注入 `MINI_ABP_DIRECTORY`/`MINI_ABP_PID`，进程 register → 收 `task-start` → 回执 + 忙态 → 结果 → idle → 可退出（协议按需拉起模型）。
- **daemon 模式**：`dataDaemon` = `bun adapter.mjs --daemon`。hub 在需要数据层查询时懒拉起/常驻，register 带 `role:"daemon"`（`directory:""`、`pid:0`），承接 `query` 帧，**不退出**。

本地手动调试：

```bash
MINI_ABP_AGENT_ID=echo MINI_ABP_DIRECTORY=/tmp/x MINI_ABP_PID=0 bun adapter.mjs        # 任务模式
MINI_ABP_AGENT_ID=echo MINI_ABP_ROLE=daemon bun adapter.mjs --daemon                   # daemon 模式
```

## 帧流程注释索引（adapter.mjs）

| 行区 | 帧 | 说明 |
|------|----|------|
| 连接 → `register` | 上行 | 连接后第一帧；`IS_DAEMON` 决定 `role`/`directory`/`pid` 字段 |
| `register-ack` | 下行 | 失败即 `process.exit(1)`（对照 §7 错误码） |
| `task-start` | 下行 | daemon 主动回 `ok:false`；task 模式：先回终态 `command-result{ok:true}`，再 busy → title → idle 事件流 |
| `command` (send) | 下行 | 回显文本为 title |
| `command` (abort) | 下行 | 回执 + `finish()`（idle + 退出） |
| `command` (其他) | 下行 | 回 `ok:false + unsupported action`（协议守则：实现不了也回执） |
| `query` 四 kind | 下行 | 见下「数据层 mock」 |
| `task-stop` | 下行 | `finish()` |
| `heartbeat` 周期 | 上行 | 30s；注册成功后发 |
| `finish()` | — | 发 idle 事件 + 100ms 后退出 |

## 数据层 mock（query 帧四 kind）

与规范 §4.2 契约**逐字核对**，命名一致：`list-sessions` / `message-query` / `delete-sessions` / `session-meta`（见 `agent.json` 的 `capabilities.dataOps`）。

- `list-sessions` → `{sessions: SessionInfo[], dbSizeBytes}`（`connected` 不用填，hub 算）。
- `message-query` → 按 `args.sessionID` 出 30 条 mock + `limit` 裁剪 + `beforeKey` 翻页，回 `{messages, hasMore, nextKey}`（`nextKey = 已返回末尾 seq`，`hasMore=false` 时省略）。
- `delete-sessions` → `{removed}`（mock：直接数 `ids.length`）。
- `session-meta` → `{ok, meta:{title, model, dbSizeBytes}}`，未命中回 `ok:false + "session not found"`。
- 未知 kind → `ok:false + unsupported kind`（前向兼容：新 kind 旧适配器按未知回执，hub 走兜底）。

改造时把 `MOCK_SESSIONS` / `mockMessages()` 替换为真实存储查询即可。

## 改造成真实 agent —— 关键修改点清单

1. **`agent.json`**
   - `id`：唯一 id（`^[a-z0-9][a-z0-9_-]{0,63}$`），与目录名一致。
   - `name` / `version`：展示用；version 建议 semver（`1.2.3`）。
   - `launch.command`/`args`：改成你的运行时（如 `node` / `deno` / 你的 CLI）。保持 `cwd:"manifest-dir"` 以便相对路径解析。
   - `launch.readyTimeoutMs`：改大到你的启动耗时（超时 = `BRIDGE_REGISTER_TIMEOUT`）。
   - `requires.binaries`：列出你的 agent CLI 及 runtime 二进制，派发前预检（缺失报 `AGENT_NOT_INSTALLED`）。缺省则每个用户机器都直接尝试 spawn。
   - `capabilities`：如实声明 `permission`（`none`/`startup-only`/`reply`）/`question`/`sessions`/`dataOps`/`abort`/`multiTurn`。声明了才有对应下行帧。
   - `dataDaemon`：有数据层才配置；`command` 非空（校验器强制）。
   - 不需要的字段可删（校验器仅强制 v/id/protocol/transport+launch/dataDaemon.command）。

2. **`adapter.mjs` 顶层常量**——`SOCK`/`AGENT_ID`/`DIRECTORY`/`PID` 读 env；改 `AGENT_ID` 默认值或不改（env 总覆盖）。

3. **`task-start` 分支**——把「回显 title」替换为真实逻辑：接到 prompt → 驱动你的 agent → 每有状态/中间产物发 `event.normalized.*` → 完成后回 `ok:true` 终态？**不**——`task-start` 的 `command-result` 用于「接受/拒绝任务」，任务完成状态经事件流表达：忙态→（可选 streaming/permission/question）→ idle。

4. **真实权限**（若 `capabilities.permission:"reply"`）：agent 需要授权时发 `event.normalized.permission {op:"set", value:{...}}`；收到下行 `command` `action="permission-reply"`（`payload.permissionId` + `reply:"once"|"always"|"reject"`）→ 执行授权 → 回 `command-result` → 发 `permission {op:"clear"}`。启动时用 flag 预授权则声明 `"startup-only"`。

5. **数据层**——把 `MOCK_SESSIONS` 换成真实存储（SQLite/JSONL/API），保持四种 query-result 契约形状。

6. **投递与验证**：
   ```bash
   node tools/validate-agent-manifest.mjs  <你的插件目录>
   # 或从模板生成：
   node tools/agent-scaffold.mjs my-agent --template bun --dir <目标>
   ```
   目录放 `<agents_dir>/<id>/` 后 `GET /agents/catalog` 或 `POST /agents/reload` 即可见。

## agent.json 字段速查

| 字段 | 必填 | 说明 |
|------|:----:|------|
| `v` | ✅ | 清单 schema 版本，恒 `1` |
| `id` | ✅ | 唯一 id，正则 `^[a-z0-9][a-z0-9_-]{0,63}$`，== 目录名 |
| `name` / `version` | — | 展示信息 |
| `protocol` | ✅ | 恒 `"abp/1"` |
| `transport` | ✅ | `"bridge"`（第三方唯一可选）|
| `launch` | ✅(bridge) | `{command, args, cwd, readyTimeoutMs}`，transport=bridge 强制 |
| `requires.binaries` | — | 二进制预检名单（缺失 → 展示 installed:false + `AGENT_NOT_INSTALLED`）|
| `capabilities` | — | `permission/question/streaming/sessions/dataOps/abort/multiTurn` |
| `dataDaemon` | — | `{command, args, cwd, readyTimeoutMs, autostart}`；`command` 非空强制 |
| `enabled` | — | `false` 禁用派发（`AGENT_DISABLED`）|
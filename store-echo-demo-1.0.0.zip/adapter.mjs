#!/usr/bin/env bun
/**
 * ABP 适配器模板（bun/node，零依赖）——echo 参考实现（含数据层示范）。
 *
 * 协议: Agent Bridge Protocol abp/1（Docs/specs/agent-bridge-protocol-v1.md）。
 * 行为: 收到 task-start 即接受 → 回报 busy → 把 prompt 回显为 title → 置 idle。
 *       收到 send 命令把文本回显为 title；abort/task-stop 置 idle 并退出。
 *       收到 query 帧（数据层）回 mock 会话/消息——示范四种 kind 的响应契约。
 * 双模式:
 *   任务模式（缺省）: 由 hub 按清单 launch 拉起，绑定 (directory, pid)。
 *   daemon 模式: `--daemon` 参数或 MINI_ABP_ROLE=daemon —— register 带
 *     `role:"daemon"`（directory:""、pid:0），承接数据层查询、常驻不退出
 *     （task-start/abort 对 daemon 无意义，静默忽略）。
 *
 * 投放: ~/.local/share/mini/agents/<id>/adapter.mjs + 同目录 agent.json（见模板根目录）。
 * 运行: 由 hub 按清单 launch / dataDaemon 拉起；任务上下文经环境变量注入：
 *   MINI_ABP_SOCK / MINI_ABP_AGENT_ID / MINI_ABP_DIRECTORY / MINI_ABP_PID / MINI_ABP_ROLE
 * 改造成真实 agent 的修改点清单 + 帧流程索引见同目录 README.md。
 */
import net from "node:net"

const SOCK = process.env.MINI_ABP_SOCK || `${process.env.HOME}/.local/share/mini/bridge.sock`
const AGENT_ID = process.env.MINI_ABP_AGENT_ID || "echo"
const DIRECTORY = process.env.MINI_ABP_DIRECTORY || process.cwd()
const PID = Number(process.env.MINI_ABP_PID || 0)
const IS_DAEMON = process.argv.includes("--daemon") || process.env.MINI_ABP_ROLE === "daemon"

const socket = net.createConnection(SOCK)
const write = (obj) => socket.write(JSON.stringify(obj) + "\n")

let registered = false

socket.on("connect", () => {
  write({
    type: "register",
    v: 1,
    protocol: "abp/1",
    agentId: AGENT_ID,
    adapterVersion: "1.0.0",
    capabilities: { permission: "none", question: false, streaming: false, sessions: true, abort: true, multiTurn: true },
    directory: IS_DAEMON ? "" : DIRECTORY,
    pid: IS_DAEMON ? 0 : PID,
    role: IS_DAEMON ? "daemon" : "task",
  })
})

let buf = ""
socket.on("data", (chunk) => {
  buf += chunk.toString()
  let idx
  while ((idx = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, idx)
    buf = buf.slice(idx + 1)
    if (!line.trim()) continue
    let frame
    try {
      frame = JSON.parse(line)
    } catch {
      continue
    }
    handle(frame)
  }
})

function handle(frame) {
  switch (frame.type) {
    case "register-ack":
      if (!frame.ok) {
        console.error(`[echo] register rejected: ${frame.error}`)
        process.exit(1)
      }
      registered = true
      break
    case "task-start":
      if (IS_DAEMON) {
        // daemon 不承接任务：按协议回拒绝回执，不静默。
        write({ type: "command-result", v: 1, id: frame.id, ok: false, error: "daemon connection does not run tasks" })
        break
      }
      // 必须先回终态回执（协议守则），再发事件流。
      write({ type: "command-result", v: 1, id: frame.id, ok: true })
      write({ type: "event", v: 1, directory: DIRECTORY, pid: PID, normalized: { status: "busy" } })
      write({
        type: "event",
        v: 1,
        directory: DIRECTORY,
        pid: PID,
        normalized: { title: { title: `echo: ${String(frame.prompt || "").slice(0, 120)}`, model: "echo-model-1" } },
      })
      setTimeout(() => {
        write({ type: "event", v: 1, directory: DIRECTORY, pid: PID, normalized: { status: "idle" } })
      }, 50)
      break
    case "command":
      if (frame.action === "send") {
        const text = frame.payload?.text || ""
        write({ type: "command-result", v: 1, id: frame.id, ok: true })
        write({
          type: "event",
          v: 1,
          directory: DIRECTORY,
          pid: PID,
          normalized: { title: { title: `echo: ${String(text).slice(0, 120)}` } },
        })
      } else if (frame.action === "abort") {
        write({ type: "command-result", v: 1, id: frame.id, ok: true })
        if (!IS_DAEMON) finish()
      } else {
        write({ type: "command-result", v: 1, id: frame.id, ok: false, error: `unsupported action: ${frame.action}` })
      }
      break
    case "query":
      handleQuery(frame)
      break
    case "task-stop":
      if (!IS_DAEMON) finish()
      break
    default:
      break // 未知帧静默忽略（前向兼容）
  }
}

// ——— 数据层（query 帧）：mock 会话存储，示范四种 kind 的响应契约 ———

const MOCK_SESSIONS = [
  {
    id: "echo_ses_0001",
    title: "echo session one",
    directory: "/tmp/echo",
    timeCreated: 1000,
    timeUpdated: 2000,
    model: "echo-model-1",
  },
  {
    id: "echo_ses_0002",
    title: "echo session two",
    directory: "/tmp/echo",
    timeCreated: 1500,
    timeUpdated: 2500,
    model: "echo-model-1",
  },
]

function mockMessages(sessionId) {
  // 30 条 mock 消息（seq 1..30，倒序返回 = 最新在前），验证翻页。
  const msgs = []
  for (let i = 30; i >= 1; i--) {
    msgs.push({
      id: `${sessionId}_m${i}`,
      seq: i,
      role: i % 2 === 1 ? "user" : "assistant",
      text: `echo message ${i}`,
      time: 1000 + i,
    })
  }
  return msgs
}

function handleQuery(frame) {
  const args = frame.args || {}
  switch (frame.kind) {
    case "list-sessions":
      write({ type: "query-result", v: 1, id: frame.id, ok: true, sessions: MOCK_SESSIONS, dbSizeBytes: 4096 })
      break
    case "message-query": {
      const all = mockMessages(args.sessionID || "echo_ses_0001")
      const limit = Math.max(1, Math.min(Number(args.page?.limit) || 20, 200))
      // beforeKey = 从该 seq 之前继续翻（更小序号）；首页无 before。
      const startIdx = args.page?.beforeKey != null
        ? all.findIndex((m) => m.seq < Number(args.page.beforeKey))
        : 0
      const slice = startIdx < 0 ? [] : all.slice(startIdx, startIdx + limit)
      const hasMore = startIdx >= 0 && startIdx + limit < all.length
      write({
        type: "query-result",
        v: 1,
        id: frame.id,
        ok: true,
        messages: slice,
        hasMore,
        nextKey: hasMore ? slice[slice.length - 1]?.seq : null,
      })
      break
    }
    case "delete-sessions":
      write({ type: "query-result", v: 1, id: frame.id, ok: true, removed: (args.ids || []).length })
      break
    case "session-meta": {
      const s = MOCK_SESSIONS.find((x) => x.id === args.sessionID)
      write({
        type: "query-result",
        v: 1,
        id: frame.id,
        ok: !!s,
        error: s ? undefined : "session not found",
        meta: s ? { title: s.title, model: s.model, dbSizeBytes: 2048 } : undefined,
      })
      break
    }
    default:
      write({ type: "query-result", v: 1, id: frame.id, ok: false, error: `unsupported kind: ${frame.kind}` })
  }
}

function finish() {
  write({ type: "event", v: 1, directory: DIRECTORY, pid: PID, normalized: { status: "idle" } })
  setTimeout(() => process.exit(0), 100)
}

socket.on("close", () => process.exit(0))
socket.on("error", (e) => {
  console.error(`[echo] socket error: ${e.message}`)
  process.exit(1)
})

// 心跳（30s；hub 当前仅日志，保活语义由连接本身体现）。
setInterval(() => {
  if (registered) write({ type: "heartbeat", v: 1, ts: Date.now() })
}, 30_000)
